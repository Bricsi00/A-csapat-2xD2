<?php
function ido($varos){


$cp = fopen("http://api.openweathermap.org/data/2.5/weather?q=".$varos."&units=metric&lang=hu&appid=cb9d90cacab0b7302686aab85a55f78b","r");

$adatok=fread($cp,1024);

$adatok_decod=json_decode($adatok);
$datum=date("Y. M. d");
$para=$adatok_decod->main->humidity;
$szel=$adatok_decod->wind->speed;
$szel=$szel*3.6;
$szelirany=$adatok_decod->wind->deg;

$hofok=$adatok_decod->main->temp;
print("<p><br>Város: ".$varos);
print("<br>Hőfok: ".$hofok." °C");
print("<br>Dátum: ".$datum);
print("<br>Pára: ".$para." %");
print("<br>Szél: ".$szel." km/h");
print("<br>Szélirány: ".$szelirany." °</p>");
require("kapcs.inc.php");
$querry = "INSERT INTO idoj (varos,hofok,datum,para,szel,szelirany) VALUES ('$varos','$hofok','$datum','$para','$szel','$szelirany')";
    mysqli_query($con,$querry) or die ('Hiba az adatbevitelnél!');
}
$varos ='Budapest,hu';
$varos2='Debrecen,hu';
$varos3='Győr,hu';
$varos4='Miskolc,hu';
ido($varos);
ido($varos2);
ido($varos3);
ido($varos4);

?>