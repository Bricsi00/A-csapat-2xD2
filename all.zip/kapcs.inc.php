<?php
$con = mysqli_connect("localhost","root","","idojaras");

// Check connection
if (mysqli_connect_errno())
  {
  print( "Adatbázis kapcsolódási hiba!  " . mysqli_connect_error());
  }
 
  
?>