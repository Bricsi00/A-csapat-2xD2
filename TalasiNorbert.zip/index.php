<?php

print("    <ul>
<li><a href=listaz.php>LISTÁZ</a></li>
<li><a href=beolvas_ment.php>Beolvas,ment</a></li>
</ul>");
?>