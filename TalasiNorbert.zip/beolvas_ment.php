<?php



function ido($varos){
$cp = fopen("http://api.openweathermap.org/data/2.5/weather?q=".$varos."&units=metric&lang=hu&appid=cb9d90cacab0b7302686aab85a55f78b","r");
$adatok=fread($cp,1024);
$adatok_decod=json_decode($adatok);
$hofok=$adatok_decod->main->temp;
$datum=date("Y,M,d");
$para=$adatok_decod->main->humidity;
$szel=$adatok_decod->wind->speed;
$szel=$szel*3.6;
$szelirany=$adatok_decod->wind->deg;

print("<br>Város: " .$varos);
print("<br>Hőfok: " .$hofok."°C");
print("<br>Dátum: " .$datum);
print("<br>Pára: " .$para."%");
print("<br>Szél: " .$szel."km/h");
print("<br>Szélirány: " .$szelirany."°<br>");
$query = "insert into idojaras (varos,hofok,datum,para,szel,szelirany) values ('$varos','$hofok','$datum','$para','$szel','$szelirany')";
require("kapcs.inc.php");
mysqli_query($con,$query) or die ('Hiba az adatbevitelnél!');
}
$varos='Budapest,hu';
$varos2='Debrecen,hu';
$varos3='Gyor,hu';
$varos4='Miskolc,hu';
$varos5='Gyal,hu';
ido($varos);
ido($varos2);
ido($varos3);
ido($varos4);
ido($varos5);



?>