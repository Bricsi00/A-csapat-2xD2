<?php
function ido($varos){
$cp=fopen("http://api.openweathermap.org/data/2.5/weather?q=".$varos."&units=metric&lang=hu&appid=cb9d90cacab0b7302686aab85a55f78b","r");
$adatok=fread($cp,1024);
$adatdecod=json_decode($adatok);
$hofok=$adatdecod->main->temp;
$date = date("Y,M,d");
$para = $adatdecod->main->humidity;
$szel = $adatdecod->wind->speed;
$szel = $szel*3.6;
$szelirany = $adatdecod->wind->deg;

print("Város: ".$varos);
print("<br>Hőfok: ".$hofok."°C");
print("<br>Dátum: ".$date);
print("<br>Páram: ".$para."%");
print("<br>Szél: ".$szel."km/h");
print("<br>Szélirány: ".$szelirany."°<p>");
require("kapcs.inc.php");
$query = "INSERT INTO idj(varos, datum, hofok, para, szel, szelirany) VALUES ('$varos','$hofok','$date','$para','$szel','$szelirany')" ;
mysqli_query($con, $query) or die ("Hiba adatbevitel");
}
$varos ='Budapest,hu';
$varos2 ='Jenő,hu';
$varos3 ='Iszkaszentgyörgy,hu';
$varos4 ='Bicske,hu';
ido($varos);
ido($varos2);
ido($varos3);
ido($varos4);

?>