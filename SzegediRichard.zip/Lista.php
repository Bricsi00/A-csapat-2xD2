<?php
require("kapcs.inc.php");
$eredm = mysqli_query($con,"SELECT * FROM idj") or die ("Nem sikerült a lekérdezés!");




while($rekord = mysqli_fetch_object($eredm)){
    print("<form action='' method='GET'>");
    print("<br>".$rekord->varos);
    print("<br>".$rekord->datum);
    print("<br>".$rekord->hofok);
    print("<br>".$rekord->para);
    print("<br>".$rekord->szel);
    print("<br>".$rekord->szelirany);
    print("</form>");}

?>